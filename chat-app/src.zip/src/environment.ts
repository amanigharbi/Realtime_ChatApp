export const environment = {
    production: false,
    firebase: {
      apiKey: "AIzaSyCEl-nHzXOPE3goH0pY2frf8bFTlAznO9M",
      authDomain: "realtime-chat-c6fe3.firebaseapp.com",
      projectId: "realtime-chat-c6fe3",
      storageBucket: "realtime-chat-c6fe3.firebasestorage.app",
      messagingSenderId: "880325492266",
      appId: "1:880325492266:web:5a523223c2f54137b78d53",
      databaseURL: "https://realtime-chat-c6fe3-default-rtdb.firebaseio.com/"
    }
  };
  